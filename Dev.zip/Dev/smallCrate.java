import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class smallCrate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class smallCrate extends Crate
{
    /**
     * Act - do whatever the smallCrate wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
